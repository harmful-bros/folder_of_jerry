// EXPORTED FUNCTIONS
#include <xstring>
_STD_BEGIN

template<class _Elem, class _Traits, class _Ax>
	template<class _It>
	void basic_string<_Elem, _Traits, _Ax>::_Construct(_It _First,
		_It _Last, input_iterator_tag)
	{	// initialize from [_First, _Last), input iterators
	_TRY_BEGIN
	for (; _First != _Last; ++_First)
		append((size_type)1, (_Elem)*_First);
	_CATCH_ALL
	_Tidy(true);
	_RERAISE;
	_CATCH_END
	}

template<class _Elem, class _Traits, class _Ax>
	template<class _It>
	void basic_string<_Elem, _Traits, _Ax>::_Construct(_It _First,
		_It _Last, forward_iterator_tag)
	{	// initialize from [_First, _Last), forward iterators
	_DEBUG_RANGE(_First, _Last);
	size_type _Count = 0;
	_Distance(_First, _Last, _Count);
	reserve(_Count);

	_TRY_BEGIN
	for (; _First != _Last; ++_First)
		append((size_type)1, (_Elem)*_First);
	_CATCH_ALL
	_Tidy(true);
	_RERAISE;
	_CATCH_END
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::append(const _Myt& _Right,
	size_type _Roff, size_type _Count)
	{	// append _Right [_Roff, _Roff + _Count)
	if (_Right.size() < _Roff)
		_String_base::_Xran();	// _Roff off end
	size_type _Num = _Right.size() - _Roff;
	if (_Num < _Count)
		_Count = _Num;	// trim _Count to size
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long

	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and append new stuff
		_Traits::copy(_Myptr() + _Mysize,
			_Right._Myptr() + _Roff, _Count);
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::append(const _Elem *_Ptr, size_type _Count)
	{	// append [_Ptr, _Ptr + _Count)
	if (_Inside(_Ptr))
		return (append(*this, _Ptr - _Myptr(), _Count));	// substring
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long

	size_type _Num;
	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and append new stuff
		_Traits::copy(_Myptr() + _Mysize, _Ptr, _Count);
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::append(size_type _Count, _Elem _Ch)
	{	// append _Count * _Ch
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long

	size_type _Num;
	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and append new stuff using assign
		_Chassign(_Mysize, _Count, _Ch);
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::assign(const _Myt& _Right,
	size_type _Roff, size_type _Count)
	{	// assign _Right [_Roff, _Roff + _Count)
	if (_Right.size() < _Roff)
		_String_base::_Xran();	// _Roff off end
	size_type _Num = _Right.size() - _Roff;
	if (_Count < _Num)
		_Num = _Count;	// trim _Num to size

	if (this == &_Right)
		erase((size_type)(_Roff + _Num)), erase(0, _Roff);	// substring
	else if (_Grow(_Num))
		{	// make room and assign new stuff
		_Traits::copy(_Myptr(), _Right._Myptr() + _Roff, _Num);
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::assign(const _Elem *_Ptr, size_type _Num)
	{	// assign [_Ptr, _Ptr + _Num)
	if (_Inside(_Ptr))
		return (assign(*this, _Ptr - _Myptr(), _Num));	// substring

	if (_Grow(_Num))
		{	// make room and assign new stuff
		_Traits::copy(_Myptr(), _Ptr, _Num);
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::assign(size_type _Count, _Elem _Ch)
	{	// assign _Count * _Ch
	if (_Count == npos)
		_String_base::_Xlen();	// result too long

	if (_Grow(_Count))
		{	// make room and assign new stuff
		_Chassign(0, _Count, _Ch);
		_Eos(_Count);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::insert(size_type _Off,
	const _Myt& _Right, size_type _Roff, size_type _Count)
	{	// insert _Right [_Roff, _Roff + _Count) at _Off
	if (_Mysize < _Off || _Right.size() < _Roff)
		_String_base::_Xran();	// _Off or _Roff off end
	size_type _Num = _Right.size() - _Roff;
	if (_Num < _Count)
		_Count = _Num;	// trim _Count to size
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long

	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and insert new stuff
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off, _Mysize - _Off);	// empty out hole
		if (this == &_Right)
			_Traits::move(_Myptr() + _Off,
				_Myptr() + (_Off < _Roff ? _Roff + _Count : _Roff),
					_Count);	// substring
		else
			_Traits::copy(_Myptr() + _Off,
				_Right._Myptr() + _Roff, _Count);	// fill hole
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::insert(size_type _Off,
	const _Elem *_Ptr, size_type _Count)
	{	// insert [_Ptr, _Ptr + _Count) at _Off
	if (_Inside(_Ptr))
		return (insert(_Off, *this,
			_Ptr - _Myptr(), _Count));	// substring
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long
	size_type _Num;
	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and insert new stuff
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off, _Mysize - _Off);	// empty out hole
		_Traits::copy(_Myptr() + _Off, _Ptr, _Count);	// fill hole
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::insert(size_type _Off,
	size_type _Count, _Elem _Ch)
	{	// insert _Count * _Ch at _Off
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (npos - _Mysize <= _Count)
		_String_base::_Xlen();	// result too long
	size_type _Num;
	if (0 < _Count && _Grow(_Num = _Mysize + _Count))
		{	// make room and insert new stuff
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off, _Mysize - _Off);	// empty out hole
		_Chassign(_Off, _Count, _Ch);	// fill hole
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::erase(size_type _Off,
	size_type _Count)
	{	// erase elements [_Off, _Off + _Count)
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (_Mysize - _Off < _Count)
		_Count = _Mysize - _Off;	// trim _Count
	if (0 < _Count)
		{	// move elements down
		_Traits::move(_Myptr() + _Off, _Myptr() + _Off + _Count,
			_Mysize - _Off - _Count);
		size_type _Newsize = _Mysize - _Count;
		_Eos(_Newsize);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::replace(size_type _Off,
	size_type _N0, const _Myt& _Right, size_type _Roff, size_type _Count)
	{	// replace [_Off, _Off + _N0) with _Right [_Roff, _Roff + _Count)
	if (_Mysize < _Off || _Right.size() < _Roff)
		_String_base::_Xran();	// _Off or _Roff off end
	if (_Mysize - _Off < _N0)
		_N0 = _Mysize - _Off;	// trim _N0 to size
	size_type _Num = _Right.size() - _Roff;
	if (_Num < _Count)
		_Count = _Num;	// trim _Count to size
	if (npos - _Count <= _Mysize - _N0)
		_String_base::_Xlen();	// result too long

	size_type _Nm = _Mysize - _N0 - _Off;	// length of preserved tail
	size_type _Newsize = _Mysize + _Count - _N0;
	if (_Mysize < _Newsize)
		_Grow(_Newsize);

	if (this != &_Right)
		{	// no overlap, just move down and copy in new stuff
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// empty hole
		_Traits::copy(_Myptr() + _Off,
			_Right._Myptr() + _Roff, _Count);	// fill hole
		}
	else if (_Count <= _N0)
		{	// hole doesn't get larger, just copy in substring
		_Traits::move(_Myptr() + _Off,
			_Myptr() + _Roff, _Count);	// fill hole
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// move tail down
		}
	else if (_Roff <= _Off)
		{	// hole gets larger, substring begins before hole
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// move tail down
		_Traits::move(_Myptr() + _Off,
			_Myptr() + _Roff, _Count);	// fill hole
		}
	else if (_Off + _N0 <= _Roff)
		{	// hole gets larger, substring begins after hole
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// move tail down
		_Traits::move(_Myptr() + _Off,
			_Myptr() + (_Roff + _Count - _N0), _Count);	// fill hole
		}
	else
		{	// hole gets larger, substring begins in hole
		_Traits::move(_Myptr() + _Off,
			_Myptr() + _Roff, _N0);	// fill old hole
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// move tail down
		_Traits::move(_Myptr() + _Off + _N0, _Myptr() + _Roff + _Count,
			_Count - _N0);	// fill rest of new hole
		}

	_Eos(_Newsize);
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::replace(size_type _Off,
	size_type _N0, const _Elem *_Ptr, size_type _Count)
	{	// replace [_Off, _Off + _N0) with [_Ptr, _Ptr + _Count)
	if (_Inside(_Ptr))
		return (replace(_Off, _N0, *this,
			_Ptr - _Myptr(), _Count));	// substring, replace carefully
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (_Mysize - _Off < _N0)
		_N0 = _Mysize - _Off;	// trim _N0 to size
	if (npos - _Count <= _Mysize - _N0)
		_String_base::_Xlen();	// result too long
	size_type _Nm = _Mysize - _N0 - _Off;

	if (_Count < _N0)
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// smaller hole, move tail up
	size_type _Num;
	if ((0 < _Count || 0 < _N0) && _Grow(_Num = _Mysize + _Count - _N0))
		{	// make room and rearrange
		if (_N0 < _Count)
			_Traits::move(_Myptr() + _Off + _Count,
				_Myptr() + _Off + _N0, _Nm);	// move tail down
		_Traits::copy(_Myptr() + _Off, _Ptr, _Count);	// fill hole
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	basic_string<_Elem, _Traits, _Ax>& basic_string<_Elem, _Traits, _Ax>::replace(size_type _Off,
	size_type _N0, size_type _Count, _Elem _Ch)
	{	// replace [_Off, _Off + _N0) with _Count * _Ch
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (_Mysize - _Off < _N0)
		_N0 = _Mysize - _Off;	// trim _N0 to size
	if (npos - _Count <= _Mysize - _N0)
		_String_base::_Xlen();	// result too long
	size_type _Nm = _Mysize - _N0 - _Off;

	if (_Count < _N0)
		_Traits::move(_Myptr() + _Off + _Count,
			_Myptr() + _Off + _N0, _Nm);	// smaller hole, move tail up
	size_type _Num;
	if ((0 < _Count || 0 < _N0) && _Grow(_Num = _Mysize + _Count - _N0))
		{	// make room and rearrange
		if (_N0 < _Count)
			_Traits::move(_Myptr() + _Off + _Count,
				_Myptr() + _Off + _N0, _Nm);	// move tail down
		_Chassign(_Off, _Count, _Ch);	// fill hole
		_Eos(_Num);
		}
	return (*this);
	}

template<class _Elem, class _Traits, class _Ax>
	void basic_string<_Elem, _Traits, _Ax>::reserve(size_type _Newcap)
	{	// determine new minimum length of allocated storage
	if (_Mysize <= _Newcap && _Myres != _Newcap)
		{	// change reservation
		size_type _Size = _Mysize;
		if (_Grow(_Newcap, true))
			_Eos(_Size);
		}
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::copy(_Elem *_Ptr,
	size_type _Count, size_type _Off) const
	{	// copy [_Off, _Off + _Count) to [_Ptr, _Ptr + _Count)
	_DEBUG_POINTER(_Ptr);
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (_Mysize - _Off < _Count)
		_Count = _Mysize - _Off;
	_Traits::copy(_Ptr, _Myptr() + _Off, _Count);
	return (_Count);
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::find(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for [_Ptr, _Ptr + _Count) beginnng at or after _Off
	_DEBUG_POINTER(_Ptr);
	if (_Count == 0 && _Off <= _Mysize)
		return (_Off);	// null string always matches (if inside string)

	size_type _Nm;
	if (_Off < _Mysize && _Count <= (_Nm = _Mysize - _Off))
		{	// room for match, look for it
		const _Elem *_Uptr, *_Vptr;
		for (_Nm -= _Count - 1, _Vptr = _Myptr() + _Off;
			(_Uptr = _Traits::find(_Vptr, _Nm, *_Ptr)) != 0;
			_Nm -= _Uptr - _Vptr + 1, _Vptr = _Uptr + 1)
			if (_Traits::compare(_Uptr, _Ptr, _Count) == 0)
				return (_Uptr - _Myptr());	// found a match
		}

	return (npos);	// no match
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::rfind(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for [_Ptr, _Ptr + _Count) beginning before _Off
	_DEBUG_POINTER(_Ptr);
	if (_Count == 0)
		return (_Off < _Mysize ? _Off : _Mysize);	// null always matches
	if (_Count <= _Mysize)
		{	// room for match, look for it
		const _Elem *_Uptr = _Myptr() +
			(_Off < _Mysize - _Count ? _Off : _Mysize - _Count);
		for (; ; --_Uptr)
			if (_Traits::eq(*_Uptr, *_Ptr)
				&& _Traits::compare(_Uptr, _Ptr, _Count) == 0)
				return (_Uptr - _Myptr());	// found a match
			else if (_Uptr == _Myptr())
				break;	// at beginning, no more chance for match
		}

	return (npos);	// no match
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::find_first_of(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for one of [_Ptr, _Ptr + _Count) at or after _Off
	_DEBUG_POINTER(_Ptr);
	if (0 < _Count && _Off < _Mysize)
		{	// room for match, look for it
		const _Elem *const _Vptr = _Myptr() + _Mysize;
		for (const _Elem *_Uptr = _Myptr() + _Off; _Uptr < _Vptr; ++_Uptr)
			if (_Traits::find(_Ptr, _Count, *_Uptr) != 0)
				return (_Uptr - _Myptr());	// found a match
		}

	return (npos);	// no match
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::find_last_of(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for one of [_Ptr, _Ptr + _Count) before _Off
	_DEBUG_POINTER(_Ptr);
	if (0 < _Count && 0 < _Mysize)
		for (const _Elem *_Uptr = _Myptr()
			+ (_Off < _Mysize ? _Off : _Mysize - 1); ; --_Uptr)
			if (_Traits::find(_Ptr, _Count, *_Uptr) != 0)
				return (_Uptr - _Myptr());	// found a match
			else if (_Uptr == _Myptr())
				break;	// at beginning, no more chance for match

	return (npos);	// no match
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::find_first_not_of(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for none of [_Ptr, _Ptr + _Count) at or after _Off
	_DEBUG_POINTER(_Ptr);
	if (_Off < _Mysize)
		{	// room for match, look for it
		const _Elem *const _Vptr = _Myptr() + _Mysize;
		for (const _Elem *_Uptr = _Myptr() + _Off; _Uptr < _Vptr; ++_Uptr)
			if (_Traits::find(_Ptr, _Count, *_Uptr) == 0)
				return (_Uptr - _Myptr());
		}
	return (npos);
	}

template<class _Elem, class _Traits, class _Ax>
	typename basic_string<_Elem, _Traits, _Ax>::size_type basic_string<_Elem, _Traits, _Ax>::find_last_not_of(const _Elem *_Ptr,
	size_type _Off, size_type _Count) const
	{	// look for none of [_Ptr, _Ptr + _Count) before _Off
	_DEBUG_POINTER(_Ptr);
	if (0 < _Mysize)
		for (const _Elem *_Uptr = _Myptr()
			+ (_Off < _Mysize ? _Off : _Mysize - 1); ; --_Uptr)
			if (_Traits::find(_Ptr, _Count, *_Uptr) == 0)
				return (_Uptr - _Myptr());
			else if (_Uptr == _Myptr())
				break;
	return (npos);
	}

template<class _Elem, class _Traits, class _Ax>
	int basic_string<_Elem, _Traits, _Ax>::compare(size_type _Off,
	size_type _N0, const _Myt& _Right,
	size_type _Roff, size_type _Count) const
	{	// compare [_Off, _Off + _N0) with _Right [_Roff, _Roff + _Count)
	if (_Right.size() < _Roff)
		_String_base::_Xran();	// _Off off end
	if (_Right._Mysize - _Roff < _Count)
		_Count = _Right._Mysize - _Roff;	// trim _Count to size
	return (compare(_Off, _N0, _Right._Myptr() + _Roff, _Count));
	}

template<class _Elem, class _Traits, class _Ax>
	int basic_string<_Elem, _Traits, _Ax>::compare(size_type _Off,
	size_type _N0, const _Elem *_Ptr, size_type _Count) const
	{	// compare [_Off, _Off + _N0) with [_Ptr, _Ptr + _Count)
	_DEBUG_POINTER(_Ptr);
	if (_Mysize < _Off)
		_String_base::_Xran();	// _Off off end
	if (_Mysize - _Off < _N0)
		_N0 = _Mysize - _Off;	// trim _N0 to size

	size_type _Ans = _N0 == 0 ? 0
		: _Traits::compare(_Myptr() + _Off, _Ptr,
			_N0 < _Count ? _N0 : _Count);
	return (_Ans != 0 ? (int)_Ans : _N0 < _Count ? -1
		: _N0 == _Count ? 0 : +1);
	}

template<class _Elem, class _Traits, class _Ax>
	void basic_string<_Elem, _Traits, _Ax>::_Copy(size_type _Newsize, size_type _Oldlen)
	{	// copy _Oldlen elements to newly allocated buffer
	size_type _Newres = _Newsize | _ALLOC_MASK;
	if (max_size() < _Newres)
		_Newres = _Newsize;	// undo roundup if too big
	else if (_Newres / 3 < _Myres / 2
		&& _Myres <= max_size() - _Myres / 2)
		_Newres = _Myres + _Myres / 2;	// grow exponentially if possible
	_Elem *_Ptr;

	_TRY_BEGIN
		_Ptr = _Mybase::_Alval.allocate(_Newres + 1);
	_CATCH_ALL
		_Newres = _Newsize;	// allocation failed, undo roundup and retry
		_TRY_BEGIN
			_Ptr = _Mybase::_Alval.allocate(_Newres + 1);
		_CATCH_ALL
		_Tidy(true);	// failed again, discard storage and reraise
		_RERAISE;
		_CATCH_END
	_CATCH_END

	if (0 < _Oldlen)
		_Traits::copy(_Ptr, _Myptr(), _Oldlen);	// copy existing elements
	_Tidy(true);
	_Bx._Ptr = _Ptr;
	_Myres = _Newres;
	_Eos(_Oldlen);
	}

template<class _Elem, class _Traits, class _Ax>
	bool basic_string<_Elem, _Traits, _Ax>::_Grow(size_type _Newsize,
	bool _Trim)
	{	// ensure buffer is big enough, trim to size if _Trim is true
	if (max_size() < _Newsize)
		_String_base::_Xlen();	// result too long
	if (_Myres < _Newsize)
		_Copy(_Newsize, _Mysize);	// reallocate to grow
	else if (_Trim && _Newsize < _BUF_SIZE)
		_Tidy(true,	// copy and deallocate if trimming to small string
			_Newsize < _Mysize ? _Newsize : _Mysize);
	else if (_Newsize == 0)
		_Eos(0);	// new size is zero, just null terminate
	return (0 < _Newsize);	// return true only if more work to do
	}

template<class _Elem, class _Traits, class _Ax>
	void basic_string<_Elem, _Traits, _Ax>::_Tidy(bool _Built,
	size_type _Newsize)
	{	// initialize buffer, deallocating any storage
	if (!_Built)
		;
	else if (_BUF_SIZE <= _Myres)
		{	// copy any leftovers to small buffer and deallocate
		_Elem *_Ptr = _Bx._Ptr;
		if (0 < _Newsize)
			_Traits::copy(_Bx._Buf, _Ptr, _Newsize);
		_Mybase::_Alval.deallocate(_Ptr, _Myres + 1);
		}
	_Myres = _BUF_SIZE - 1;
	_Eos(_Newsize);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
