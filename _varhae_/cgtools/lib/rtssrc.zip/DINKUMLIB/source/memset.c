/* memset function */

#if defined(__TI_COMPILER_VERSION__)
#undef  _INLINE
#define _STRING_IMPLEMENTATION
#define _MEMSET
#include <string.h>
#else /* defined(__TI_COMPILER_VERSION__) */
#include <string.h>
_STD_BEGIN

void *(memset)(void *s, int c, size_t n)
	{	/* store c throughout unsigned char s[n] */
	const unsigned char uc = (unsigned char)c;
	unsigned char *su = (unsigned char *)s;

	for (; 0 < n; ++su, --n)
		*su = uc;
	return (s);
	}
_STD_END
#endif /* defined(__TI_COMPILER_VERSION__) */
/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
