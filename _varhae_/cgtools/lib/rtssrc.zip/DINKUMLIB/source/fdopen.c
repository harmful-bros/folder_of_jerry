/* fdopen function */
#include "xstdio.h"
_STD_BEGIN

FILE *(fdopen)(_FD_TYPE fd, const char *mods)
	{	/* open a file, given fd */
	return (fd < 0 || FOPEN_MAX <= fd ? 0 : _Files[fd]);
	}
_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
